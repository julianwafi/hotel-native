Free Download Source Code "Hotel Native By Gilang Aqshal Ilham Safatullah"

FIRST Download

1.XAMPP

2."TEXT EDITOR" Gue menggunakan VSCODE

3"Hotel_Native"

4. Download the zip file/ download winrar

5. Extract the file and copy "Hotel_Native" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name hotel_db

6. Import hotel_db.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Hotel_Native


**LOGIN DETAILS** 
Admin
user: admin
pass: admin123
